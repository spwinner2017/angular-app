$(function(){

    $(".sample-content").mCustomScrollbar({
            axis:"xy",
            scrollButtons:{
                enable:true
            }
        });

    $("#accordion .panel-body").mCustomScrollbar({
        //setHeight:100,
        theme:"dark-3"
    });

    //console.log("I fired cleanly!");
    
});  


 