import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppViewComponent } from './views/app-view/app-view-component/app-view.component';
const routes: Routes = [
  {
    path: '',
    component: AppViewComponent,
    loadChildren:'./modules/dashboard/dashboard.modules#DashboardModule'
  }
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
