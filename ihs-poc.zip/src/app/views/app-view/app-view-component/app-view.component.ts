import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-view-component',
  templateUrl: './app-view.component.html',
  styleUrls: ['./app-view.component.css']
})
export class AppViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
